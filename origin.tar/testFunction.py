from getloc import *

getLocation('128.6.13.155')

